<template>
	<section class="promo">
		<div class="container">
			<h1 class="title">My SSR Blog! With Nuxt.js</h1>
			<p>
				Lorem, ipsum dolor sit amet consectetur adipisicing elit. Aspernatur
				dolor doloremque ipsum incidunt dolores voluptates numquam eum ullam
				iste expedita!
			</p>
		</div>
	</section>
</template>

<style lang="scss">
.promo {
	text-align: center;

	p {
		color: #999;
	}
}
</style>
